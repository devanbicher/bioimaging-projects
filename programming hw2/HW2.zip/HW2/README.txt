simply run the program, it will bring up a GUI that will allow you to do everything from within the GUI
once the GUI is open you can hit color or gray and it will run on a default image.
The image will come up and then hit the next button to move to the next images of the segmentation results
Once the last image of the clustering is up, you can load another image by typing in the file or the relative path, 
if the directory is the main directory matlab is running from, and the file then hitting enter then hitting the new file button.
When the new file button is pressed the new image will come up automatically, then hitting either the gray or color button
will start the segmentation, again hitting next will move to the next image of the segmentation process.
Finally all this can be done with different number of clusters from 2 to 100.
the cluster value should be set before the color or gray button is pressed.
You can also start the process over again by hitting color or gray and it will start the segmentation again 