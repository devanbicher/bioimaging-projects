The running of this assingment is very simple:

in MATLAB open the file: dlb213_hw_1.m

it will prompt for the path of the folder with the brain or heart images, I ran my code with the brain images
enter the path with single quotes:
'path/to/folder'

it will tell you what to do and what is being displayed, but press any key to move from image to image
they will be displayed in a seperate window

once it is done with the tasks for the brain images it will move on and ask for for the path for the tiff sequences
similarly enter the path with single quotes:
'new/path/to/folder/for/tiffs'

it will once again cycle through everything that is required for the assignment, however this time no key press is needed
it will cycle through automatically